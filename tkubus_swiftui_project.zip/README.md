TKU Bus Helper - SwiftUI iOS Project

This folder contains the Swift source files for the TKU Bus Helper app.
Drop these into a new Xcode SwiftUI project and add the appropriate Info.plist entries,
App Icons, and Background Modes as described in the project scaffold.

Files included:
- TKUBusApp.swift
- AppDelegate.swift
- Models/
- ViewModels/
- Views/
- ScheduleManager.swift

See the original conversation for detailed build instructions and Info.plist keys.
